# Orlixa — Android App

A small Cordova shell around **https://orlixa.art/app/**. It adds a native
splash/loading screen, an offline/error screen with Retry, and requests
camera + microphone permission so the AI tools can use them.

## Get the APK (GitHub Actions)

1. Push this project to GitHub (branch `main`).
2. Open the **Actions** tab → **Build Android APK** (runs on every push, or
   press **Run workflow**).
3. When it finishes, open the run and download **orlixa-debug-apk** from
   *Artifacts*. Unzip and install the `.apk` (uninstall any old version first).

This is a debug build. For the Play Store you need a signed release build.

## Project layout

| Path | Purpose |
|------|---------|
| `config.xml` | App id/name/version, permissions, allow-list, icons, splash, plugins |
| `package.json` | Cordova platform + plugin versions |
| `www/js/config.js` | **App settings** (URL, load mode, timeouts, permissions, messages) |
| `www/js/app.js` | Shell logic: state machine, permissions, loading/error handling |
| `www/index.html`, `www/css/app.css` | Loading + error screens |
| `res/android/` | Launcher icons and splash image |
| `.github/workflows/main.yml` | APK build |

## Settings (`www/js/config.js`)

- `appUrl` — site to open (must be https)
- `loadMode` — `'direct'` (recommended: opens the site as the main page) or
  `'iframe'` (keeps it inside the shell; the server must allow framing)
- `timeoutMs`, `revealDelayMs`, `permissions`, `statusBarColor`, `messages`

Invalid values fall back to defaults and log a warning.

## Server requirements

- **direct mode:** nothing special.
- **iframe mode:** the site must not send `X-Frame-Options: SAMEORIGIN`; send
  `Content-Security-Policy: frame-ancestors 'self' https://localhost` and use
  `SameSite=None; Secure` session cookies.
- Google sign-in does not work inside a WebView ("disallowed_useragent");
  open the login in the system browser instead.

## Camera / microphone

`config.xml` declares CAMERA and RECORD_AUDIO and `app.js` asks for them at
launch. If you tapped *Deny* before: Settings → Apps → Orlixa → Permissions.

## Allowed domains

Only `orlixa.art` (and subdomains) opens inside the app; other links open in
the system browser. If the site must load another domain (payments, auth),
add it to `<allow-navigation>` in `config.xml` and to the CSP `<meta>` tag in
`www/index.html`.

## Local preview

`npm install && npm run dev` serves `www/` in a desktop browser (no native
features).
